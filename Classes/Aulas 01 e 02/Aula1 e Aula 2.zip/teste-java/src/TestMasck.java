import java.awt.Container;
import java.text.ParseException;
import javax.swing.JFormattedTextField;
import javax.swing.JFrame;



public class TestMasck {

	public static void main(String[] args) {
		
	}

}
