import java.awt.*;
import javax.swing.*;


public class Ex08_aula02 extends JFrame {
	
	private JButton okJButton;
	private JComboBox colorJComboBox;
	private JPanel panel1;
	
	
	public Ex08_aula02() {
		super ("Caixa de Sele��o");
		
		setLayout ( new BorderLayout());
		
		colorJComboBox = new JComboBox();
		colorJComboBox.addItem("Item 1");
		colorJComboBox.addItem("Item 2");
		colorJComboBox.addItem("Item 3");
		add( colorJComboBox, BorderLayout.NORTH );
		
		okJButton = new JButton ( "Ok ");
		panel1 = new JPanel();
		panel1.add(okJButton);
		add( panel1, BorderLayout.SOUTH);
		
		
	}
	
	public static void main (String [] args)	{
		Ex08_aula02 exJComboBox = new Ex08_aula02();
		exJComboBox.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		exJComboBox.setSize(200, 100);
		exJComboBox.setVisible(true);
	}

}
