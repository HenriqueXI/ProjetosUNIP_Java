import javax.swing.JOptionPane;


public class Ex02_aula01 {
	
	public static void main (String [] args ) {
		
		JOptionPane.showMessageDialog(null,
				"Montando uma caixa de dialogo sem icone",
				"Mensagem",
				JOptionPane.PLAIN_MESSAGE);
		
	}
}




