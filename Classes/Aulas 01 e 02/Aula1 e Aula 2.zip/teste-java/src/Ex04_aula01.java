import javax.swing.JOptionPane;


public class Ex04_aula01 {
	
	public static void main (String [] args) {
		
		String numero=JOptionPane.showInputDialog(null,
				"Digite qualquer informa��o",
				 "Entrada de dados",
				 JOptionPane.QUESTION_MESSAGE);
	}
	

}
