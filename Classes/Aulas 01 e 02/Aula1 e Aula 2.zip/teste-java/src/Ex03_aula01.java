import javax.swing.JOptionPane;



public class Ex03_aula01 {

	public static void main(String[] args) {
			
		int opcao = JOptionPane.showConfirmDialog(null,
				"Deseja terminar??",
				"Mensagem final",
				JOptionPane.YES_NO_OPTION,
				JOptionPane.QUESTION_MESSAGE);

	}

}
