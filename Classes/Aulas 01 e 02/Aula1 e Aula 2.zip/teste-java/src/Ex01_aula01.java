
import javax.swing.JFrame;


public class Ex01_aula01 {

	public static void main(String[] args) {
		
		JFrame frame = new JFrame ("Exemplo de frame");
		frame.setSize(300, 300);
		frame.setVisible(true);

	}

}