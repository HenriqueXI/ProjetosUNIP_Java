import java.awt.Container;
import java.awt.FlowLayout;
import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;




public class Ex05_aula2 extends JFrame {
	
	private JLabel labelNome, labelEnd;
	private JTextField tFNome, tFEndereco;
	private JButton btOk;
	
	
	public Ex05_aula2()
	{
		super("Exemplo FlowLayout");
		setDefaultCloseOperation(EXIT_ON_CLOSE);
		labelNome = new JLabel("Nome: ");
		tFNome = new JTextField(15);
		labelEnd = new JLabel("Endere�o: ");
		tFEndereco = new JTextField(15);
		btOk = new JButton ("OK");
		
		Container janela;
		janela = getContentPane();
				
				
		janela.setLayout(new FlowLayout());
		janela.add(labelNome);
		janela.add(tFNome);
		janela.add(labelEnd);
		janela.add(tFEndereco);
		janela.add(btOk); 
		
		
		setSize(400, 200);
	}
	
	
	public static void main (String [] args) {
		Ex05_aula2 ex = new Ex05_aula2();
		ex.setVisible(true); 
	}
	

}
